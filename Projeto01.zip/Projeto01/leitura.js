import chalk from 'chalk';
import fs from 'fs';

function trataErro(erro){
    throw new Error(chalk.red(erro.code, "Não há arquivos no caminho"));
}

async function leArquivo(caminhoDoArquivo){
    const endcoding = 'utf-8';
    const texto = await fs.promises.readFile(caminhoDoArquivo, endcoding)
    console.log(chalk.green(texto))
    }

export default leArquivo;