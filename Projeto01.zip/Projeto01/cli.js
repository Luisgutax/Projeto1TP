import chalk from "chalk";
import pegaArquivo from "./index.js";
import validaURL from "./http-validacao.js";
import leArquivo from "./leitura.js";

const caminho = process.argv;

async function processaTexto(caminhoDoArquivo){
    const resultado = await pegaArquivo(caminhoDoArquivo[2]);
    
    if(caminho[3] === "valida"){
        console.log(chalk.yellow('Links Válidos'), await validaURL(resultado));
    } else if(caminho[3] === "leitura"){
        console.log(await leArquivo(caminhoDoArquivo[2]));
    } else if(caminho[3] === "links"){
        console.log(chalk.bgYellow('Lista de Links: '), resultado);
    } else{
        console.log(chalk.redBright("Erro no programa"))
    }
}

//console.log(pegaArquivo(caminho[2]));

processaTexto(caminho);